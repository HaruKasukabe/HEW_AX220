//=============================================================================
//
//  �S�[��[Goal.h]
// ����y�s
//=============================================================================
#pragma once
#include "main.h"

HRESULT InitGoal();
void UninitGoal();
void UpdateGoal();
void DrawGoal();