#pragma once
#define OGUSU_YUUKO
//#define KATO