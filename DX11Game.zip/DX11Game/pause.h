//=============================================================================
//
// �Q�[���̈ꎞ��~ [pause.h]
// Author : ����y�s
//
//=============================================================================
#pragma once

#include "main.h"

HRESULT InitPause();
void UninitPause();
bool UpdatePause();
void DrawPause();