//===================================================
//		�X�e�[�W�Z���N�g[stageselect.h]
//����C�l
//=====================================================

#pragma once
#include "main.h"

HRESULT InitStageSelect();
void UninitStageSelect();
void UpdateStageSelect();
void DrawStageSelect();
