//===================================================
//		�}�b�v�Z���N�g[mapselect.h]
//����C�l
//=====================================================

#pragma once
#include "main.h"

HRESULT InitMapSelect();
void UninitMapSelect();
void UpdateMapSelect();
void DrawMapSelect();
